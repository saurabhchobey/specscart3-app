import React from 'react';
import '../../App.css';
import Cards from '../Cards';
import Footer from '../Footer';

export default function SignUp() {
  return <><h1 className='sign-up'>saurabh chobey</h1>
  <Cards/>
  <Footer/>
  </>;
}
