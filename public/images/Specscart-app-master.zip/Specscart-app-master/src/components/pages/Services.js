import React from 'react';
import '../../App.css';
import Banner from '../Banner';
import Cards from '../Cards';
import Footer from '../Footer';

import { Button } from '../Button';
import '../HeroSection.css';


export default function Services() {
  const image='https://farm2.staticflickr.com/1638/26145024230_06acd55d1b_b.jpg'
  return <>
  {/* <h1 className='services'>SERVICES</h1> */}
  <Banner className='Banner'>
  
  

  </Banner>
  <Cards/>
  <Footer/>
  </>;
}
