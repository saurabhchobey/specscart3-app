import React from 'react'

const Banner = () => {
    return (
        <>
        
        <div className='Banner'>
           

           </div></>

    )
}

export default Banner
